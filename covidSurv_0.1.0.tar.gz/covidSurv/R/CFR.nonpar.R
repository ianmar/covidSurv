CFR.nonpar <- function(cases,deaths,plot.results=TRUE,max.d=30,steps=1,
                       est.start=0.05,eps=1e-07,maxiter=1000000) {

  Fd<-design.CFR(cases,max.d,steps)
  T<-dim(Fd)[1]
  Td<-dim(Fd)[2]
  crude<-max(deaths)/max(cases)
  Deaths<-diff(c(0,as.numeric(deaths))) # daily new deaths
  Deaths[Deaths<0]<-0 #in case there are negative deaths e.g. due to re-adjustments

  res<-nnpois(Deaths,Fd,rep(1,T),rep(0,T),rep(est.start,Td),control=addreg.control(epsilon=eps,maxit=maxiter))
  if (res$conv==FALSE) warning("linear Poisson fit did not converge - may need more iterations")
  probs<-res$coef
  death.cdf<-rep(0,max.d)
    if (steps>1) {
    probs<-cumsum(probs*steps)
    for (i in 1:length(probs)) {
      death.cdf[((i-1)*steps+1):(i*steps)]<-probs[i]
    }
  }
  if (steps==1) death.cdf<-(cumsum(probs))
  CFR<-death.cdf[max.d]

  if (plot.results) {
    sfun<-stepfun(1:max.d,c(0,death.cdf))
    plot(sfun,lwd=2,main=" ",ylab="cumulative case fatality risk",xlab="days since diagnosis",do.points=FALSE)
  }

  death.cdf<-cbind(0:max.d,c(0,death.cdf))
  if (CFR<crude) {
    death.cdf[,2]<-death.cdf[,2]*(crude/CFR)
    CFR<-crude
  }
  colnames(death.cdf)<-c("day","cumulative risk")
  out<-list(CFR=CFR,death.cdf=death.cdf)
  out
}
