CFR.shifted <- function(cases,deaths,start=1,shift.range=c(1:10)) {

  T<-length(cases)
  if (start>1) {
    deaths<-deaths[start:T]
    cases<-cases[start:T]
  }
  ldeaths<-log(deaths)
  lcases<-log(cases)

#---------------------------------------------------------------------------
# function for measuring discrepancy (SS=mean squares) between log(cases) and log(deaths)
#         after applying a fixed time shift
  SS<-function(lCFR,lcases,ldeaths,Tshift) {
    TSS<-length(lcases)
    ldeaths.fitted<-ldeaths[-c(1:Tshift)]+lCFR
    ss<-mean((lcases[-c((TSS-Tshift+1):TSS)]-ldeaths.fitted)**2)
    ss}
#---------------------------------------------------------------------------

SSvec<-0
CFRvec<-0
count<-0
for (i in shift.range) {
count<-count+1
res<-optimise(SS,interval=c(0,5),lcases=lcases,ldeaths=ldeaths,Tshift=i)
SSvec[count]<-res$objective
CFRvec[count]<-1/exp(res$minimum)
}

out<-cbind(CFRvec,shift.range,SSvec)
colnames(out)<-c("CFR","shift","mean squares")

CFR<-CFRvec[1]
shift<-shift.range[1]
if (length(shift.range)>1) {
opt<-sort(out[,3],index.return=TRUE)
shift<-out[opt$ix[1],2]
CFR<-out[opt$ix[1],1]
}

list(CFR=CFR,shift=shift,SS=out)

}




