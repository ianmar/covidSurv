CFR.par.age <- function(Cases,Deaths,dist="exp",meanint=c(0.05,20)) {
  
# function for parametric CFR analysis on age-specific data, assuming a common 
# time-to-death distribution in the age groups but different CFRs between age groups
  
  # Note: Cases and Deaths are matrices of age-specific cases and deaths over time
  # Note: unlike for CFR.par, Cases and Deaths are daily counts, not cumulative counts
  
  #------------------------------------------------------------------------
  # 2 embedded functions relating to profile likelihood
  #------------------------------------------------------------------------
  
  # 1. profile age-specific log-likelihood as a function of the non-CFR parameters (rate and shape)
  profile.ll <- function(rate,shape,Cases,Deaths,dist="exp") {
    
    if ((rate>0)&(shape>0)) {
      TT<-dim(Cases)[1] # number of time points
      A<-dim(Cases)[2] # number of age groups
      mu<-matrix(0,TT,A)
      for (t in 1:TT) {
        if (dist=="exp") pt.rate<-exp(-rate*c((t-1):0))*(1-exp(-rate))
        if (dist=="gamma") pt.rate<-pgamma(c(t:1),shape=shape,rate=rate)-pgamma(c((t-1):0),shape=shape,rate=rate)
        for (a in 1:A) {
        ct<-Cases[1:t,a]
        mu[t,a]<-sum(ct*pt.rate)
        }
      }
      
      cfr<-colSums(Deaths)/colSums(mu)
      out<-0
      for (a in 1:A) out<-out+sum(Deaths[mu[,a]>0,a]*log(cfr[a]*mu[mu[,a]>0,a])-cfr[a]*mu[mu[,a]>0,a])
    }
    
    if ((rate<=0)|(shape<=0)) out <- -10^10
    
    out
    
  }
  #------------------------------------------------------
  
  # 2. modified version of profile likelihood
  # equivalent to the profile.ll function but only requires the first 2 arguments (rate and shape)
  # this reduction is required for one of the optimisation routines
  profile.reduced <- function(cases,deaths,dist) {
    
    out<-function(par) {profile.ll(par[1],par[2],Cases,Deaths,dist)}
    out
  }
  
  #----------------------------------------------
  
  # start of main function
  
    # calculate the exponential CFR estimate
    rateint<-c(1/meanint[2] , 1/meanint[1])
    rate.exp<-optimise(profile.ll,interval=rateint,maximum=TRUE,shape=1,Cases=Cases,Deaths=Deaths,dist="exp")$maximum
    TT<-dim(Cases)[1]
    A<-dim(Cases)[2]
    mu<-matrix(0,TT,A)
    for (t in 1:TT) {
      pt.rate<-exp(-rate.exp*c((t-1):0))*(1-exp(-rate.exp))
      for (a in 1:A) {
      ct<-Cases[1:t,a]
      mu[t,a]<-sum(ct*pt.rate)
      }
    }
    
    if (dist=="exp") {
      cfr<-colSums(Deaths)/colSums(mu)
      dist<-"exponential"
      rate<-rate.exp
      shape<-1
    }
    #-----------------------------------------------
    
    # calculate the gamma CFR estimate if required
    if (dist=="gamma") {
      objective<-profile.reduced(Cases,Deaths,dist)
      pars<-optim_nm(objective,k=2,start=c(rate.exp,1),maximum=TRUE)$par
      rate<-pars[1]
      shape<-pars[2]
      mu<-matrix(0,TT,A)
      for (t in 1:TT) {
        pt<-pgamma(c(t:1),shape=shape,rate=rate)-pgamma(c((t-1):0),shape=shape,rate=rate)
        for (a in 1:A) {
        ct<-Cases[1:t,a]
        mu[t,a]<-sum(ct*pt)
        }
      }
      cfr<-colSums(Deaths)/colSums(mu)
    }
    
    out<-list(CFR=cfr,distribution=dist,rate=rate,shape=shape)
    out
    
  }

#--------------------------------------------------------


  

  
  