CFRboot <- function(CFRnpar,cases,deaths,nboot=1000,pcntiles=c(25,975),seed=NULL,sig2.thresh=0.05,prob.thresh=0.000001,trace=TRUE) {

  set.seed(seed)
  cases.daily<-diff(c(0,cases))
  cases.daily[cases.daily<0]<-0
  deaths.daily<-diff(c(0,deaths))
  deaths.daily[deaths.daily<0]<-0
  T=length(cases)
  case.times<-rep(1,cases.daily[1])
  for (t in 2:T) case.times<-c(case.times,rep(t,cases.daily[t]))
  N<-length(case.times)
  CFR<-CFRnpar$CFR
  death.prob<-CFRnpar$death.cdf
  death.prob[,2]<-diff(c(0,death.prob[,2]))
  max.d<-max(death.prob[,1])
  sig2<-1
  if (sig2.thresh<1) {
    Fd<-design.CFR(cases,max.d,1)
    death.fits<-Fd%*%death.prob[-1,2]
    sig2.calc<-(death.fits>=sig2.thresh)
    res<-(deaths.daily[sig2.calc]-death.fits[sig2.calc])/sqrt(death.fits[sig2.calc])
    p<-sum(death.prob[,2]>prob.thresh)
    sig2<-sum(res**2)/(sum(sig2.calc)-p)
    sig2<-max(sig2,1)
  }
  rho<-(sig2-1)/(N-1)
  CFR.rep<-0

  for (i in 1:nboot) {
    n.fatal<-rbetabinom(n=1,size=N,prob=CFR,rho=rho) # incorporates overdispersion in the variance
    fatal<-sample(c(rep(1,n.fatal),rep(0,N-n.fatal)))
    delay.fatal<-sample(x=death.prob[,1],size=n.fatal,replace=TRUE,prob=death.prob[,2])
    delay<-rep(Inf,N)
    delay[fatal==1]<-delay.fatal
    death.times<-case.times+delay
    boot.times<-sort(unique(death.times))
    boot.times<-boot.times[boot.times<Inf]
    num.times<-length(boot.times)
    deaths.counts<-0
    for (t in 1:num.times) deaths.counts[t]<-sum(death.times==boot.times[t])
    deaths.daily.i<-rep(0,T)
    deaths.daily.i[boot.times]<-deaths.counts
    deaths.i<-cumsum(deaths.daily.i[1:T])
    result<-CFR.nonpar(cases,deaths.i,plot.results=FALSE,max.d=max.d)
    CFR.rep[i]<-result$CFR
    if (trace) print(i)
  }

  CFR.rep<-sort(CFR.rep)
  CI.low<-CFR.rep[pcntiles[1]]
  CI.upp<-CFR.rep[pcntiles[2]]
  out<-list(replications=CFR.rep,CI=c(CI.low,CI.upp))
  out

}
