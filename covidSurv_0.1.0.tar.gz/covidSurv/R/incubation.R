incubation <- function(mean.inc=5.2,perc95=12.5,I.max=30,mean.test=2) {

  # solve for parameters of the log-normal incubation distribution
  a<-(1/2)
  b<- -qnorm(0.95)
  c<-log(perc95/mean.inc)
  sigma<-(-b-sqrt(b**2-4*a*c))/(2*a)
  mu<-log(5.2)-a*sigma**2
  days<-seq(0,(I.max+1),.01)
  days.int<-c(1:(I.max+1))
  inc.dens<- (1/(days*sigma*sqrt(2*pi)))*exp(-(1/(2*sigma**2))*(log(days)-mu)**2)
  inc.dens[1]<-0
  inc.cdf<-pnorm((log(days)-mu)/sigma)
  inc.cdf.int<-pnorm((log(days.int)-mu)/sigma)
  prob.inc<-diff(c(0,inc.cdf.int))
  prob.inc<-prob.inc/sum(prob.inc) # just in case not exactly equal to 1
  out<-cbind((days.int-1),prob.inc)
  colnames(out)<-c("day","probability function")

  # convolve with testing delay
  if (mean.test>0) {
  shape=1.2
  rate=shape/mean.test
  test.dens<-dgamma(days,shape=shape,rate=rate)
  test.cdf<-pgamma(days,shape=shape,rate=rate)
  count<-0
  conv.cdf<-0
  for (d in days) {
    count<-count+1
    conv.cdf[count]<-sum(inc.dens[1:count]*test.cdf[count:1])*0.01
  }
  out<-cbind(c(0:I.max),diff(c(0,conv.cdf[seq(101,(I.max+1)*100+1,100)]))/conv.cdf[(I.max+1)*100+1])
  colnames(out)<-c("day","probability function")
  }

  out
}
