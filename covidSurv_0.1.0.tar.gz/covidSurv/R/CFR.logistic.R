CFR.logistic <- function(cases.age,deaths.age,age,interval) {

  cases.a<-colSums(cases.age)
  deaths.a<-colSums(deaths.age)
  CFR.a<-deaths.a/cases.a

  dev.L <- function(L,deaths.a,cases.a,age) {
    deaths.adj<-(deaths.a/L)
    suppressWarnings(glm(cbind((cases.a-deaths.adj),deaths.adj)~age,family=binomial)$dev)
  }

  fit.L <- function(deaths.a,cases.a,age,L) {
    deaths.adj<-(deaths.a/L)
    suppressWarnings(glm(cbind((cases.a-deaths.adj),deaths.adj)~age,family=binomial)$coef)
  }

  calc.curve<-function(L,par1,par2,age) L/(1+exp(par1+par2*age))

  L.opt<-optimise(dev.L,interval=interval,deaths.a=deaths.a,cases.a=cases.a,age=age)$minimum
  par.opt<-fit.L(deaths.a,cases.a,age,L.opt)

  L0<-L.opt
  L1<-par.opt[1]
  L2<-par.opt[2]
  list(L0=L0,L1=L1,L2=L2)

}
