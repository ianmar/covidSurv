CFR.age <- function(CFRnpar,CFRb,agedata,cases,deaths,nboot=1000,pcntiles=c(25,975),seed=NULL,trace=TRUE) {

  set.seed(seed)
  ngrps<-length(agedata$agegrp)
  ncases<-max(cases)
  ndeaths<-max(deaths)
  alpha<-agedata$cases
  beta<-agedata$deaths
  agedata$cases<-round(alpha*ncases)
  agedata$deaths<-round(beta*ndeaths)
  individ.cases<-rep(1,agedata$cases[1])
  for (g in 2:ngrps) individ.cases<-c(individ.cases,rep(g,agedata$cases[g]))
  individ.deaths<-c(rep(1,agedata$deaths[1]),rep(0,(agedata$cases[1]-agedata$deaths[1])))
  for (g in 2:ngrps) individ.deaths<-c(individ.deaths,c(rep(1,agedata$deaths[g]),rep(0,(agedata$cases[g]-agedata$deaths[g]))))
  CFR.age<-CFRnpar$CFR*beta/alpha
  names(CFR.age)<-agedata$agegrp
  CFR.reps<-matrix(0,nboot,ngrps)
  for (i in 1:nboot) {
    cases.i<-sample(ncases,replace=TRUE)
    individ.cases.i<-individ.cases[cases.i]
    individ.deaths.i<-individ.deaths[cases.i]
    CFR.i<-sample(CFRb$replications,size=1)
    alpha.i<-0
    beta.i<-0
    for (g in 1:ngrps) {
      alpha.i[g]<-sum(individ.cases.i==g)
      beta.i[g]<-sum(individ.deaths.i[individ.cases.i==g])
    }
    alpha.i<-alpha.i/sum(alpha.i)
    beta.i<-beta.i/sum(beta.i)
    CFR.reps[i,]<-CFR.i*beta.i/alpha.i
    if (trace) print(i)
  }

  CI<-matrix(0,ngrps,2)
  rownames(CI)<-agedata$agegrp
  for (g in 1:ngrps) {
    CFRg<-sort(CFR.reps[,g])
    CI[g,]<-c(CFRg[pcntiles[1]],CFRg[pcntiles[2]])
  }

  out<-list(CFR=CFR.age,CI=CI,replications=CFR.reps)
  out
}
