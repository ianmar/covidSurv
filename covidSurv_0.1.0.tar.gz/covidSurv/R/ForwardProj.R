ForwardProj <- function(BP,dist,proj.days=5,extrap.method="last",extrap.user=NULL) {

    I.max<-length(dist[,1])-1
    T<-length(BP$day)
    T.days<-T+I.max
    if (extrap.method=="last") extrap.inf<-rep(BP$infections[T],proj.days)
    if (extrap.method=="lower") extrap.inf<-rep(0,proj.days)
    if (extrap.method=="user") extrap.inf<-extrap.user
    infections<-c(rep(0,I.max),BP$infections,extrap.inf)
    F<-design.BP(T+proj.days,dist)
    cases<-F%*%infections
    projs<-cbind(c((T+1):(T+proj.days)),cases[-c(1:T.days)])
    colnames(projs)<-c("day","forecast")

    out<-list(day=projs[,1],projection=projs[,2])
    out
}
