design.CFR <- function(cases,max.d,steps) {

  Cases<-diff(c(0,as.numeric(cases))) # daily new cases
  Cases[Cases<0]<-0 #in case there are negative counts e.g. due to re-adjustments
  T<-length(Cases)
  F<-matrix(0,T,max.d)
  for (d in 1:max.d) F[,d]<-c(rep(0,(d-1)),Cases[1:(T-d+1)])
  if (steps>1) {
    nsteps<-max.d/steps
    Fstep<-matrix(0,T,nsteps)
    for (s in 1:nsteps) {
      rnge<-c(((s-1)*steps+1):(s*steps))
      Fstep[,s]<-rowSums(F[,rnge])
    }
    F<-Fstep
  }
  F
}
