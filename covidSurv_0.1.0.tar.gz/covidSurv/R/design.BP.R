design.BP <- function(T,dist) {

  prob<-dist[,2]
  I.max<-length(prob)-1
  T.days<-T+I.max
  F<-matrix(0,T.days,T.days)
  for (d in 1:T.days) {
    start<-max(0,(d-I.max))+1
    length.f<-length(c(start:d))
    F[d,c(start:d)]<-prob[length.f:1]
  }
  F
}
