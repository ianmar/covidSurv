CFR.par <- function(cases,deaths,dist="exp",meanint=c(0.05,20),CFR.fixed=TRUE,CFR=1,explore=FALSE) {

#------------------------------------------------------------------------
# 3 embedded functions relating to profile likelihood
#------------------------------------------------------------------------

# 1. profile log-likelihood as a function of the non-CFR parameters (rate and shape)
profile.ll <- function(rate,shape,cases,deaths,dist="exp",CFR.fixed=TRUE,CFR=1) {

  if ((rate>0)&(shape>0)) {
    T<-length(cases)
    Cases<-diff(c(0,cases))
    Deaths<-diff(c(0,deaths))
    mu<-0
  for (t in 1:T) {
    ct<-Cases[1:t]
    if (dist=="exp") pt.rate<-exp(-rate*c((t-1):0))*(1-exp(-rate))
    if (dist=="gamma") pt.rate<-pgamma(c(t:1),shape=shape,rate=rate)-pgamma(c((t-1):0),shape=shape,rate=rate)
    mu[t]<-sum(ct*pt.rate)
  }

  if (CFR.fixed) cfr<-CFR
  if (!(CFR.fixed)) cfr<-deaths[T]/sum(mu)
  out<-sum(Deaths[mu>0]*log(cfr*mu[mu>0])-cfr*mu[mu>0])
  }

  if ((rate<=0)|(shape<=0)) out <- -10^10

  out

}
#------------------------------------------------------

# 2. modified version of profile likelihood
# equivalent to the profile.ll function but only requires the first 2 arguments (rate and shape)
# this reduction is required for one of the optimisation routines
profile.reduced <- function(cases,deaths,dist,CFR.fixed,CFR) {

  out<-function(par) {profile.ll(par[1],par[2],cases,deaths,dist,CFR.fixed,CFR)}
  out
}

#----------------------------------------------

# 3. function for exploring the maximum in the exponential model to determine the meanint range to give CFR.par
profile.explore <- function(rate.range,cases,deaths,dist="exp",CFR.fixed,CFR) {
  #
  # rate.range is a range of rates in the exponential model to plot the profile log-likelihood over
  # cases is a series of cumulative cases
  # deaths is a series of cumulative deaths

  count<-0
  prof.expl<-0
  for (r in rate.range) {
    count<-count+1
    prof.expl[count]<-profile.ll(r,1,cases,deaths,dist,CFR.fixed,CFR)
  }
  plot(rate.range,prof.expl,type="l",ylab="profile log-like",xlab="rate")
}

#----------------------------------------------------------

# start of main function

if (explore) {
  rate.range=seq(1/meanint[2],1/meanint[1],.001)
  profile.explore(rate.range,cases,deaths,"exp",CFR.fixed,CFR)
}

if (!explore) {
# calculate the exponential CFR estimate
rateint<-c(1/meanint[2] , 1/meanint[1])
rate.exp<-optimise(profile.ll,interval=rateint,maximum=TRUE,shape=1,cases=cases,deaths=deaths,dist="exp",CFR.fixed=CFR.fixed,CFR)$maximum
T<-length(cases)
Cases<-diff(c(0,cases))
mu<-0
for (t in 1:T) {
  ct<-Cases[1:t]
  pt.rate<-exp(-rate.exp*c((t-1):0))*(1-exp(-rate.exp))
  mu[t]<-sum(ct*pt.rate)
}

if (dist=="exp") {
  if (CFR.fixed) cfr<-CFR
  if (!(CFR.fixed)) cfr<-deaths[T]/sum(mu)
  dist<-"exponential"
  rate<-rate.exp
  shape<-1
}
#-----------------------------------------------

# calculate the gamma CFR estimate if required
if (dist=="gamma") {
  objective<-profile.reduced(cases,deaths,dist,CFR.fixed,CFR)
  pars<-optim_nm(objective,k=2,start=c(rate.exp,1),maximum=TRUE)$par
  rate<-pars[1]
  shape<-pars[2]
  for (t in 1:T) {
      ct<-Cases[1:t]
      pt<-pgamma(c(t:1),shape=shape,rate=rate)-pgamma(c((t-1):0),shape=shape,rate=rate)
      mu[t]<-sum(ct*pt)
  }
  if (CFR.fixed) cfr<-CFR
  if (!(CFR.fixed)) cfr<-deaths[T]/sum(mu)
}

out<-list(CFR=cfr,distribution=dist,rate=rate,shape=shape)
out

}

}

#--------------------------------------------------------



