BackProj <- function(cases,dist,pre.smooth=TRUE,post.smooth=TRUE,
            pre.df=8,post.df=8,constr.final=TRUE,est.start=100,eps=1e-06,maxiter=1000000) {

  F<-design.BP(length(cases),dist)
  prob<-dist[,2]
  T<-length(cases)
  I.max<-length(prob)-1
  T.days<-T+I.max
  Cases<-c(rep(0,I.max),diff(c(0,as.numeric(cases)))) # daily new cases
  Cases[Cases<0]<-0 # just in case the data have negative diagnoses e.g. due to re-adjustments
  Cases.fit<-Cases
  if (pre.smooth) {
    pre.fit <- suppressWarnings(gam(Cases~s(1:T.days,df=pre.df),
                            family=poisson(link="log"))$fitted.values)
    Cases.fit <- round(pre.fit) #non-integers causes problems in nnpois
  }

  F.full<-F
  if (constr.final) {
    F[,(T.days-1)]<-F[,(T.days-1)]+F[,T.days]
    F<-F[,-T.days]
  }
  cf<-as.numeric(constr.final)

  bound.tol<-1e-06
  if (eps<=1e-06) bound.tol<-2*eps
  res<-nnpois(Cases.fit,F,rep(1,T.days),rep(0,T.days),rep(est.start,(T.days-cf)),
              control=addreg.control(bound.tol=bound.tol,epsilon=eps,maxit=maxiter))
  if (res$conv==FALSE) warning("linear Poisson fit did not converge - may need more iterations or larger tolerance")
  infections.est<-res$coef
  if (constr.final) {
  infections.est[T.days-1]<-infections.est[T.days-1]/2
  infections.est[T.days]<-infections.est[T.days-1]
  }
  infections.est<-round(infections.est)
  if (post.smooth) infections.est <- suppressWarnings(gam(infections.est~s(1:T.days,df=post.df),
                            family=poisson(link="log"))$fitted.values)
  fits<-F.full%*%infections.est

  out<-cbind(1:T,Cases[-c(1:I.max)],Cases.fit[-c(1:I.max)],fits[-c(1:I.max)],infections.est[-c(1:I.max)])
  rownames(out)<-NULL
  list(day=out[,1],observed=out[,2],smoothed=out[,3],fitted=out[,4],infections=out[,5])
}
