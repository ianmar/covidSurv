BPboot <- function(BP,dist,nboot=100,pcntiles=c(5,95),pre.smooth=TRUE,post.smooth=TRUE,pre.df=8,post.df=8,constr.final=TRUE,est.start=100,eps=1e-06,maxiter=1000000,proj.days=0,seed=NULL,edf=8,trace=TRUE,omit.zeros=50,extrap.method="last",extrap.user=NULL) {

set.seed(seed)
cases<-BP$observed
fitted<-BP$fitted
T<-length(cases)
resids<-(cases-fitted)/sqrt(fitted)
if (omit.zeros>0) {
  for (i in 1:omit.zeros) if (cases[i]==0) omit<-i # omit early zeros in calculation of over-dispersion parameter
  sig2<-sum(resids[-c(1:omit)]**2)/((T-omit-1)-edf) # overdispersion parameter
}
if (omit.zeros==0) sig2<-sum(resids**2)/((T-1)-edf) # overdispersion parameter

# unsmoothed estimates for generating bootstrap samples
fitted.unsmth<-BackProj(cumsum(cases),dist,pre.smooth=FALSE,post.smooth=FALSE,
                        constr.final=constr.final,est.start=est.start,eps=eps,maxiter=maxiter)$fitted
# minor numerical adjustment to avoid zero fitted values
fitted.unsmth[fitted.unsmth==0]<-min(fitted.unsmth[fitted.unsmth!=0])
samp.boot<-matrix(0,nboot,T)
cases.boot<-matrix(0,nboot,T)
proj.boot<-0
if (proj.days>0) proj.boot<-matrix(0,nboot,proj.days)
for (i in 1:nboot) {
  # set first obs to 0 to avoid NAs
  cases.boot[i,]<-c(0,rnbinom(n=(T-1),mu=fitted.unsmth[-1],size=(1/(sig2-1))*fitted.unsmth[-1]))
  cases.boot[i,]<-round(cases.boot[i,])
  boot.i<-BackProj(cumsum(cases.boot[i,]),dist,pre.smooth=pre.smooth,post.smooth=post.smooth,pre.df=pre.df,
                   post.df=post.df,constr.final=constr.final,
                   est.start=est.start,eps=eps,maxiter=maxiter)
  samp.boot[i,]<-boot.i$infections
  if (proj.days>0) proj.boot[i,]<-ForwardProj(boot.i,dist,proj.days,extrap.method,extrap.user)$projection
  if (trace) print(i)
}

# calculate percentile CIs
CI.lo<-0
CI.hi<-0
CI.proj.lo<-0
CI.proj.hi<-0
for (t in 2:T) {
  CI.lo[t]<-sort(samp.boot[,t])[pcntiles[1]]
  CI.hi[t]<-sort(samp.boot[,t])[pcntiles[2]]
}
for (t in 1:proj.days) {
  if (proj.days>0) CI.proj.lo[t]<-sort(proj.boot[,t])[pcntiles[1]]
  if (proj.days>0) CI.proj.hi[t]<-sort(proj.boot[,t])[pcntiles[2]]
}

out<-list(bootstrap.estimates=samp.boot,bootstrap.samples=cases.boot,CI=cbind(CI.lo,CI.hi),bootstrap.projections=proj.boot,CI.proj=cbind(CI.proj.lo,CI.proj.hi))

out

}
